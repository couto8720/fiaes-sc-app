var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__092l01sw2773s._.js")
R.c("server/chunks/[root-of-the-server]__195k5a68t2i15._.js")
R.m(89997)
module.exports=R.m(89997).exports
