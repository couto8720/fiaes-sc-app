var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/migration-sql/route.js")
R.c("server/chunks/[externals]__0pyhwjabsbg1z._.js")
R.c("server/chunks/_1-u9evp7ybjl0._.js")
R.c("server/chunks/[root-of-the-server]__1uv-wzynojl57._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_next-internal_server_app_api_migration-sql_route_actions_1gmz_9u63u1ji.js")
R.m(63668)
module.exports=R.m(63668).exports
