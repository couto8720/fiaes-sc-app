var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[externals]__1a-p53i0xidcg._.js")
R.c("server/chunks/node_modules_next_dist_16uekqf-emgzs._.js")
R.c("server/chunks/_1rbd81eryasrk._.js")
R.c("server/chunks/[root-of-the-server]__1uv-wzynojl57._.js")
R.c("server/chunks/node_modules_next_0g8xe7c6fvfgl._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_15vc_89wprgh5.js")
R.m(77067)
module.exports=R.m(77067).exports
